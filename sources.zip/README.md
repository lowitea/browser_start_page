# Lowit's Start Page

## Installation

Open link [https://lowitea.github.io/browser_start_page/lowits_start_page-3.7.xpi](https://lowitea.github.io/browser_start_page/lowits_start_page-3.7.xpi)
